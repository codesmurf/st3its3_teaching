﻿namespace HospitalBedLib.Buzzers
{
    public interface IBuzzer
    {
        void Buzz();
    }
}