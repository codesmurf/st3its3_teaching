﻿namespace HospitalBedLib.Filters
{
    public interface IFilter
    {
        bool Filter(bool sample);
    }

}
