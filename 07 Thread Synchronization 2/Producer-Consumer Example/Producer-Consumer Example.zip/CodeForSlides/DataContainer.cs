﻿namespace CodeForSlides
{
    class DataContainer
    {
        private int tyrePressure;

        public int GetTyrePressure()
        {
            return tyrePressure;
        }

        public void SetTyrePressure(int value)
        {
            tyrePressure = value;
        }
    }
}
