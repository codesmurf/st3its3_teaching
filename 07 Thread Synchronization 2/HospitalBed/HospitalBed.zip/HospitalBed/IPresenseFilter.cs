﻿namespace HospitalBed
{
    internal interface IPresenseFilter
    {
        public bool AddPresenseSample(bool presence);
    }
}