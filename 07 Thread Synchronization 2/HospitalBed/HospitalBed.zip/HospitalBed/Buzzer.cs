﻿
namespace HospitalBed
{
    internal class Buzzer
    {
        internal void StartBuzzing()
        {
            Console.WriteLine("Buzzing!!!");
        }

        internal void StopBuzzing()
        {
            Console.WriteLine("Not buzzing.");
        }
    }
}