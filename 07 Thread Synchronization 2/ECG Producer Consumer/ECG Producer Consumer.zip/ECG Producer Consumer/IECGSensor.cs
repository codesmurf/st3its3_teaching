﻿namespace ECG_Producer_Consumer;

internal interface IECGSensor
{
    public int GenerateSample();
}