﻿namespace ECG_Producer_Consumer;

internal class ECGReading
{
    public int Reading { get; set; }
}