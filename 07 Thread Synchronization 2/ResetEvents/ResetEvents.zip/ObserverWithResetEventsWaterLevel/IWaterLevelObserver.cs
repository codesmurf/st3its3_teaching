﻿namespace ObserverWithResetEventsWaterLevel;

public interface IWaterLevelObserver
{
    public void Update(int waterLevel);
}