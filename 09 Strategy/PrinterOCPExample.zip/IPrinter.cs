﻿using System.Collections.Generic;

namespace PrinterOCPExample
{
    interface IPrinter
    {
        void Print(List<string> text);
    }
}
