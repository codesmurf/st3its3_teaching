﻿namespace HospitalBed
{
    public interface IAlarm
    {
        void Sound();
        void Silence();
    }
}