﻿namespace HospitalBed
{
    public interface IFilter
    {
        bool FilterSample(bool sample);
    }
}