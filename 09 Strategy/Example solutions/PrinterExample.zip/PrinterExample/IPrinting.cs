﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrinterExample
{
    internal interface IPrinting
    {
        void Print(string text);
    }
}
