﻿namespace TextEditor
{
    public interface IPrinter
    {
        void PrintText(string currentText);
    }
}