﻿namespace HospitalBed
{
    public class PresenceSensorDataContainer
    {
        public bool PresenceDetected { get; set; }

        public PresenceSensorDataContainer()
        {
            PresenceDetected = false;
        }
    }
}