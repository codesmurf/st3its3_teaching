﻿namespace HospitalBed
{
    public interface IFilter
    {
        bool Filter(bool sample);
    }
}
