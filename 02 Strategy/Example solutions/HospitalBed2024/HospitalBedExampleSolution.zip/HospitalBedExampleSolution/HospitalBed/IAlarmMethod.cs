﻿namespace HospitalBed
{
    public interface IAlarmMethod
    {
        public void StartAlarm();

        public void StopAlarm();
    }
}