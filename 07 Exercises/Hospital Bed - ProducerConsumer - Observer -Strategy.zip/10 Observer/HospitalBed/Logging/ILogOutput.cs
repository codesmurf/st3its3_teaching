﻿namespace HospitalBed.Logging
{
    public interface ILogOutput
    {
        void Log(string logString);
    }
}