﻿namespace HospitalBed.Logging
{
    public class ConsoleLogOutput : ILogOutput
    {
        public void Log(string logString)
        {
            System.Console.WriteLine(logString);
        }
    }
}