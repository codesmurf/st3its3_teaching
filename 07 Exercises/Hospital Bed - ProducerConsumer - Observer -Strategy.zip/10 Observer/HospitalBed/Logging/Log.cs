﻿using System;
using HospitalBed.PresenceDetectorObserver;

namespace HospitalBed.Logging
{
    public class Log : IPresenceDetectorObserver
    {
        private readonly BedControl _patientPresenceSource;
        private ILogOutput _output;

        public Log(BedControl patientPresenceSource, ILogOutput output)
        {
            _patientPresenceSource = patientPresenceSource;
            _patientPresenceSource.Attach(this);
            _output = output;
        }

        public void Update()
        {
            if (_patientPresenceSource.CurrentPresenceState == false) // Patient has left the bed
            {
                _output.Log(DateTime.Now.ToShortDateString() + " "+ DateTime.Now.ToShortTimeString() + ": Patient left bed");
            }
        }
    }
}
