﻿using System;
using System.Collections.Concurrent;
using HospitalBed.Filtering;
using HospitalBed.PresenceDetectorObserver;

namespace HospitalBed
{
    public class BedControl : PresenceDetectorSubject
    {
        private readonly BlockingCollection<PresenceSensorDataContainer> _presenceDataQueue;
        public bool CurrentPresenceState = false;
        public IFilter Filter { private get; set; }
        
        public BedControl(BlockingCollection<PresenceSensorDataContainer> presenceDataQueue, IFilter filter)
        {
            _presenceDataQueue = presenceDataQueue;
            Filter = filter;
        }


        public void Run()
        {
            while (!_presenceDataQueue.IsCompleted)
            {
                HandleOneSample();
            }
            Console.WriteLine("No more data expected");
        }

        public void HandleOneSample()
        {
            try
            {
                var presenceData = _presenceDataQueue.Take();
                var newPresenceState = Filter.FilterSample(presenceData.PresenceDetected);
                if (newPresenceState != CurrentPresenceState)
                {
                    CurrentPresenceState = newPresenceState;
                    Notify();
                }
            }
            catch (InvalidOperationException)
            {
                // IOE means that Take() was called on a completed collection.
            }
        }
    }
}
