﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalBed.PresenceDetectorObserver;

namespace HospitalBed.Alarming
{
    public class AlarmController : IPresenceDetectorObserver
    {
        public IAlarm AlarmMethod { private get; set; }
    
        private readonly BedControl _patientPresenceSource;
        public AlarmController(IAlarm alarmMethod, BedControl patientPresenceSource)
        {
            AlarmMethod = alarmMethod;
            patientPresenceSource.Attach(this);
            _patientPresenceSource = patientPresenceSource;
        }

        public void Update()
        {
            if (_patientPresenceSource.CurrentPresenceState == false)
            {
                AlarmMethod.Sound();
            }
            else
            {
                AlarmMethod.Silence();
            }
        }
    }
}
