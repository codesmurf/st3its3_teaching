﻿namespace HospitalBed.Alarming
{
    public interface IAlarm
    {
        void Sound();
        void Silence();
    }
}