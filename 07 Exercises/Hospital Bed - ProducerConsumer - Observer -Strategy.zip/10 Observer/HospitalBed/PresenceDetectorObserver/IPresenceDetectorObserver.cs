﻿namespace HospitalBed.PresenceDetectorObserver
{
    public interface IPresenceDetectorObserver
    {
        void Update();
    }
}