﻿using System;
using System.Collections.Concurrent;
using System.Threading;

namespace HospitalBed
{
    public class PresenceSensor
    {
        private readonly BlockingCollection<PresenceSensorDataContainer> _presenceDataQueue;
        private readonly Random _random = new Random();

        private const int SampleTime = 100;

        public PresenceSensor(BlockingCollection<PresenceSensorDataContainer> presenceDataQueue)
        {
            _presenceDataQueue = presenceDataQueue;
        }

        private bool GetSample()
        {
            return Convert.ToBoolean(_random.Next(0, 2));  // 0 = false, 1 = true
        }

        public void Run()
        {
            while (true)
            {
                PresenceSensorDataContainer _presenceSensorDataContainer = new PresenceSensorDataContainer();
                _presenceSensorDataContainer.PresenceDetected = GetSample();
                _presenceDataQueue.Add(_presenceSensorDataContainer);
                 Thread.Sleep(SampleTime);
            }
        }

    }
}
