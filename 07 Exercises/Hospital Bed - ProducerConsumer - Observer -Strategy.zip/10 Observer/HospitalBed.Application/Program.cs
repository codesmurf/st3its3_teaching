﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using HospitalBed.Alarming;
using HospitalBed.Filtering;
using HospitalBed.Logging;

namespace HospitalBed.Application
{
    class Program
    {
        static void Main()
        {
            BlockingCollection<PresenceSensorDataContainer> presenceDataQueue = new BlockingCollection<PresenceSensorDataContainer>();
            BedControl bedControl = new BedControl(presenceDataQueue, new NoiseFilter());
            AlarmController alarming = new AlarmController(new Buzzer(), bedControl);  // This should hook "alarming" up as an observer of "bedcontrol"
            Log log = new Log(bedControl, new ConsoleLogOutput());

            PresenceSensor presenceSensor = new PresenceSensor(presenceDataQueue);

            Thread bedControlThread = new Thread(bedControl.Run);
            bedControlThread.IsBackground = true; // the thread shall stop, when the main thread exits

            Thread presenceSensorThread = new Thread(presenceSensor.Run);
            presenceSensorThread.IsBackground = true;

            bedControlThread.Start();
            presenceSensorThread.Start();

            // EYE CANDY: A simple console menu to change between filtering and alarming strategies
            bool cont = true;
            Console.WriteLine("Control menu:");
            Console.WriteLine("-------------------");
            Console.WriteLine("[R]    Set raw filtering");
            Console.WriteLine("[N]    Set noise filtering");
            Console.WriteLine("[B]    Set buzzer alarm");
            Console.WriteLine("[L]    Set light alarm");

            while (cont)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                switch (key.KeyChar)
                {
                    case 'R':
                    case 'r':
                        bedControl.Filter = new RawFilter();
                        break;

                    case 'N':
                    case 'n':
                        bedControl.Filter = new NoiseFilter();
                        break;

                    case 'B':
                    case 'b':
                        alarming.AlarmMethod = new Buzzer();
                        break;

                    case 'L':
                    case 'l':
                        alarming.AlarmMethod = new Light();
                        break;

                    case 'q':
                    case 'Q':
                        cont = false;
                        break;
                }
            }
        }

    }
}
