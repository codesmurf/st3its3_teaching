using System.Collections.Generic;

namespace Json
{
    public class NestedConfigurations
    {
        public List<AlarmSettings> alarms { get; set; }
    }
}