﻿namespace HospitalBed.PresenceSensing
{
    public interface IPresenceSensor
    {
        bool Sense();
    }
}
