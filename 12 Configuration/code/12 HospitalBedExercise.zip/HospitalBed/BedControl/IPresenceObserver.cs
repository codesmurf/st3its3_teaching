﻿namespace HospitalBed.BedControl
{
    public interface IPresenceObserver
    {
        void Update();
    }
}