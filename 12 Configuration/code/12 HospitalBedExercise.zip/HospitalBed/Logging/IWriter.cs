namespace HospitalBed.Logging
{
    public interface IWriter
    {
        void Write(string s);
    }
}