﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ObserverExample
{
    internal interface IBloodPressureObserver
    {
        public void Update();
    }
}
