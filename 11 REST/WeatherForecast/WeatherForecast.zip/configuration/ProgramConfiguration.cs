﻿namespace WeatherForecast.configuration
{
    internal class ProgramConfiguration
    {
        public string? OpenWeatherMapApiKey { get; set; }
    }
}
