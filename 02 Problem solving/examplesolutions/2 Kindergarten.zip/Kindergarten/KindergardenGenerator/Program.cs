﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KindergardenGenerator
{
    class Program
    {
        // Ex A1
        static void Main(string[] args)
        {
            List<String> childNames2018 = new List<string>() {
                "Ida", "Emma", "Alma", "Ella", "Sofia", "Freja", "Josefine", "Clara", "Anna", "Karla", "Laura", "Alberte", "Olivia", "Agnes", "Nora",
                "William", "Noah", "Oscar", "Lucas", "Victor", "Malthe", "Oliver", "Alfred", "Carl", "Valdemar", "Emil", "Elias", "August", "Aksel", "Magnus"
                };
            // Read values from cmd
            Console.WriteLine("Write number of children:");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Write age as min-max:");
            var ages = Console.ReadLine().Split('-');
            var minAge = int.Parse(ages[0]);
            var maxAge = int.Parse(ages[1]);

            Random random = new Random();
            // Write to file
            using (StreamWriter sw = new StreamWriter(@"C:\Users\Public\childnames.txt"))
            {
                // Generate children
                for (int i = 0; i < n; i++)
                {
                    sw.WriteLine("{0}, {1}", childNames2018[random.Next(childNames2018.Count)], random.Next(minAge, maxAge+1));
                }
            }
        }
    }
}
