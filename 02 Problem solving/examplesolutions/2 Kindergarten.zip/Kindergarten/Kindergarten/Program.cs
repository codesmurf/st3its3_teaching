﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kindergarten
{
    class Program
    {
        static string filename = "childnames.txt";

        static void Main(string[] args)
        {
            List<String> boys = new List<string>()
            {
                "Noah", "Victor", "Oliver", "Oscar", "William", "Lucas", "Carl", "Malthe", "Emil", "Alfred",
                "Frederik", "Valdemar", "Magnus", "Elias", "Christian", "Alexander", "August", "Anton", "Villads", "Aksel", "Nohr",
                "Johan", "Liam", "Sebastian", "Mikkel"
            };

            ChildStatistic childStatistic = new ChildStatistic(filename);

            Console.WriteLine("Ex1: Number of child names {0}", childStatistic.NumberOfChildren());
            Console.WriteLine("Ex2: Number of children named 'Sofie': {0}", childStatistic.NumberOfChildWithName("Sofie"));
            Console.WriteLine("Ex3: Average age of children named 'Oscar': {0}", childStatistic.AverageAgeOfChildrenWithName("Oscar"));
            Console.WriteLine("Ex3: Number of children aged 6 years: {0}", childStatistic.NumberOfChildrenWithAge(6));
            Console.WriteLine("Ex4: Number of boys {0}", childStatistic.NumberOfChildrenInList(boys));

            var girlsNames = childStatistic.GirlsNames(boys);
            girlsNames.Sort();
            Console.WriteLine("Ex6: Girls names are {0}", string.Join(",", girlsNames));

            var mostOfGender = (childStatistic.NumberOfChildrenInList(boys) > (childStatistic.NumberOfChildren() / 2))
                ? "boys"
                : "girls";
            Console.WriteLine("Ex7: Which genders is over representated {0}", mostOfGender);

            Console.WriteLine("Ex8: Most popular  name for boys: {0} and girls {1}", childStatistic.MostPopularNameInList(boys), childStatistic.MostPopularNameInList(childStatistic.GirlsNames(boys)));

            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }

        public class ChildStatistic
        {
            private List<Child> children;

            public ChildStatistic(List<Child> children)
            {
                this.children = children;
            }

            public ChildStatistic(string filename)
            {
                this.children = new List<Child>();

                var lines = File.ReadAllLines(filename);
                foreach (var line in lines)
                {
                    children.Add(new Child(line));
                }
            }


            // Ex 4
            public int NumberOfChildrenWithAge(int age)
            {
                int counter = 0;
                foreach (var child in children)
                {
                    if (child.Age == age) counter++;
                }

                return counter;
            }

            // Ex 1
            public int NumberOfChildren()
            {
                return children.Count;
            }

            // Ex 2
            public int NumberOfChildWithName(string name)
            {
                int counter = 0;
                foreach (var child in children)
                {
                    if (child.Name.Equals(name)) counter++;
                }

                return counter;
            }

            // Ex 3
            public double AverageAgeOfChildrenWithName(string name)
            {
                int counter = 0;
                int sum = 0;
                foreach (var child in children)
                {
                    if (child.Name.Equals(name))
                    {
                        counter++;
                        sum += child.Age;
                    }
                }

                return ((double)sum) / counter;
            }

            // Ex 5
            public int NumberOfChildrenInList(List<string> boys)
            {
                int counter = 0;
                foreach (var child in children)
                {
                    if (boys.Contains(child.Name))
                    {
                        counter++;
                    }
                }

                return counter;
            }

            // Ex 7
            public List<string> GirlsNames(List<string> boys)
            {
                HashSet<string> girls = new HashSet<string>();

                foreach (var child in children)
                {
                    if (!boys.Contains(child.Name))
                    {
                        girls.Add(child.Name);
                    }
                }

                return girls.ToList();
            }

            // Ex 8
            public string MostPopularNameInList(List<string> names)
            {
                IDictionary<String, int> namesCount = new Dictionary<string, int>();

                foreach (var child in children)
                {
                    if (names.Contains(child.Name))
                    {
                        int value;
                        if (!namesCount.TryGetValue(child.Name, out value))
                        {
                            value = 0;
                        }

                        namesCount[child.Name] = value + 1;
                    }
                }

                var max = int.MinValue;
                string name = "";
                foreach (var i in namesCount)
                {
                    if (i.Value > max)
                    {
                        max = i.Value;
                        name = i.Key;
                    }
                }

                return name;
            }



        }
        public class Child
        {
            public string Name { get; private set; }
            public int Age { get; private set; }

            public Child(String line)
            {
                var parts = line.Split(',');
                Name = parts[0].Trim();
                Age = Int32.Parse(parts[1].Trim());
            }
        }
    }
}
