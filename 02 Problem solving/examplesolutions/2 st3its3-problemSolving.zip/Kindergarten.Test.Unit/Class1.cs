﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Kindergarten.Test.Unit
{
    [TestFixture]
    public class KindergartenUnitTest
    {
        private Kindergarten uut;
        //private List<Person> emptyList = new List<Person>();

        [SetUp]
        public void SetUp()
        {
            
        }

        [Test]
        public void GetNChildren_EmptyList_CountIsZero()
        {
            uut = new Kindergarten(new List<Person>());
            Assert.That(uut.GetNChildren(), Is.Zero);
        }

        [Test]
        public void GetNChildren_SinglePersonInList_CountIsOne()
        {
            var persons = new List<Person>() {new Person("Theis", 4)};
            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildren(), Is.EqualTo(1));
        }

        [Test]
        public void GetNChildren_ManyPersonInList_CountIsCorrect()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 4),
                new Person("Signe", 3),
                new Person("Sofie", 5),
            };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildren(), Is.EqualTo(3));
        }


        [TestCase("John", 0)]
        [TestCase("Signe", 1)]
        [TestCase("Sofie", 3)]
        public void GetNChildrenOfName_CountIsCorrect(string name, int expectedCount)
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 4),
                new Person("Signe", 3),
                new Person("Sofie", 5),
                new Person("Sofie", 6),
                new Person("Sofie", 4),
            };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildrenOfName(name), Is.EqualTo(expectedCount));
        }

        [TestCase("Signe", 3.0)]
        [TestCase("Sofie", 4.0)]
        public void GetAverageAgeOf_AverageAgeIsCorrect(string name, double expectedAvg)
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 4),
                new Person("Signe", 3),
                new Person("Sofie", 5),
                new Person("Sofie", 6),
                new Person("Sofie", 1),
            };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetAverageAgeOf(name), Is.EqualTo(expectedAvg));
        }

        [Test]
        public void GetAverageAgeOf_NoChildrenWithName_ExceptionThrown()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 4),
                new Person("Signe", 3),
                new Person("Sofie", 5),
                new Person("Sofie", 6),
                new Person("Sofie", 1),
            };

            uut = new Kindergarten(persons);
            Assert.Throws<ArgumentOutOfRangeException>(() => uut.GetAverageAgeOf("John"));
        }

        [TestCase(2, 0)]
        [TestCase(3,2)]
        [TestCase(4,3)]
        public void GetNChildrenOfAge_CountCorrect(int age, int expectedCount)
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 3),
                new Person("Signe", 4),
                new Person("Sofie", 3),
                new Person("Sofie", 4),
                new Person("Sofie", 4),
            };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildrenOfAge(age), Is.EqualTo(expectedCount));
        }

        public void GetNChildrenOfNames_NoChildrenWithAnyOfTheNames_CountIsZero()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 3),
                new Person("Signe", 4),
                new Person("Sofie", 3),
                new Person("Sofie", 4),
                new Person("Sofie", 4),
            };

            var names = new List<string> {"John", "Pedro"};

            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildrenOfNames(names), Is.Zero);
        }

        public void GetNChildrenOfNames_OneWithAnyOfTheNames_CountIsCorrect()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 3),
                new Person("Signe", 4),
                new Person("Sofie", 3),
                new Person("Sofie", 4),
                new Person("Sofie", 4),
            };

            var names = new List<string> { "John", "Sofie" };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildrenOfNames(names), Is.EqualTo(3));
        }


        public void GetNChildrenOfNames_SeveralWithAnyOfTheNames_CountIsCorrect()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 3),
                new Person("Signe", 4),
                new Person("Sofie", 3),
                new Person("Sofie", 4),
                new Person("Sofie", 4),
            };

            var names = new List<string> { "Theis", "Signe", "Sofie", "Ib" };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetNChildrenOfNames(names), Is.EqualTo(5));
        }


        public void GetUniqueNames_PersonListEmpty_CountIsZero()
        {
            uut = new Kindergarten(new List<Person>());
            Assert.That(uut.GetUniqueNames().Count, Is.Zero);
        }

        public void GetUniqueNames_PersonListNoDuplicates_CountIsCorrect()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 3),
                new Person("Signe", 4),
                new Person("Sofie", 3)
            };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetUniqueNames().Count, Is.EqualTo(3));
        }

        public void GetUniqueNames_PersonListWithDuplicates_CountIsCorrect()
        {
            var persons = new List<Person>()
            {
                new Person("Theis", 3),
                new Person("Signe", 4),
                new Person("Sofie", 3),
                new Person("Sofie", 3),
                new Person("Sofie", 3)
            };

            uut = new Kindergarten(persons);
            Assert.That(uut.GetUniqueNames().Count, Is.EqualTo(3));
        }


    }
}
