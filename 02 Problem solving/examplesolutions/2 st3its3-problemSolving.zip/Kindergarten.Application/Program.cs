﻿using System;
using System.Linq;

namespace Kindergarten.Application
{
    class Program
    {
        static void Main(string[] args)
        {
            FileReader reader = new FileReader();
            var persons = reader.ReadPersons(@"..\..\..\Data\childnames.txt");
            var boysNames = reader.ReadNames(@"..\..\..\Data\boysnames.txt");
            Kindergarten kindergarten = new Kindergarten(persons);

            //Exercise 1:
            //How many children are there?
            Console.WriteLine($"EX1: Number of children:\t\t" + kindergarten.GetNChildren());

            //    Exercise 2:
            //How many children are named “Sofie”?
            Console.WriteLine($"EX2: Number of children named Sofie:\t" + kindergarten.GetNChildrenOfName("Sofie"));


            //Exercise 3:
            //What is the average age of “Oscar”?
            Console.WriteLine("EX3: Average age of Oscar:\t\t{0:0.##}", kindergarten.GetAverageAgeOf("Oscar"));


            //Exercise 4:
            //How many 6 years olds are there?
            Console.WriteLine($"EX4: Number of children aged 6:\t\t" + kindergarten.GetNChildrenOfAge(6));

            //    Exercise 5:
            //How many boys are there?
            Console.WriteLine($"EX5: Number of boys:\t\t\t" + kindergarten.GetNChildrenOfNames(boysNames));


            //    Exercise 6:
            //What are the girls names ? (the list of unique names)
            var allNames = kindergarten.GetUniqueNames();
            var girlsNames = allNames.Except(boysNames).ToList();

            Console.Write("EX6: Girls' names: ");
            foreach (var girlName in girlsNames)
            {
                Console.Write( girlName + ", ");
            }
            Console.WriteLine("");


            //Exercise 7:
            //Are there more boys than girls or is it the other way around?
            Console.Write($"EX7: Are there more boys than girls?\t");
            Console.WriteLine(kindergarten.IsMostBoys(boysNames) ? "Yes" : "No");

            //    Exercise 8:
            //What is the most popular name for a boy and for a girl?
            Console.WriteLine($"EX8: Most popular BOYS name:\t\t" + kindergarten.GetMostPopularNameOf(boysNames));
            Console.WriteLine($"EX8: Most popular GIRLS name:\t\t" + kindergarten.GetMostPopularNameOf(girlsNames));

            // To ensure program does not terminate prematurely in Debug mode
            Console.WriteLine("Press any key");
            Console.ReadKey();

        }
    }
}
