﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Kindergarten
{
    public class FileReader
    {
        // Reads a list of PERSON info
        public List<Person> ReadPersons(string fileName)
        {
            var personLines = File.ReadAllLines(fileName);
            var persons = new List<Person>();

            foreach (var personLine in personLines)
            {
                string[] personParts = personLine.Split(',');
                persons.Add(new Person(personParts[0], Convert.ToInt32(personParts[1])));
            }

            return persons;
        }

        // Reads a list of NAME info
        public List<string> ReadNames(string fileName)
        {
            return File.ReadAllLines(fileName).ToList();
        }
    }
}
