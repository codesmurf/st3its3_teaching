﻿using System;
using System.Collections.Generic;

namespace Kindergarten
{
    public class Kindergarten
    {
        private List<Person> _children;

        // A Kindergarten is only a Kindergarten if there are children in it, 
        // so the list of children are taken as a constructor parameter
        // ("No kindergarten without children")
        public Kindergarten(List<Person> children)
        {
            _children = children;
        }

        // Used in solution to Exercise 1
        public int GetNChildren()
        {
            return _children.Count;
        }

        // Used in solution to Exercise 2
        public int GetNChildrenOfName(string name)
        {
            int childrenOfName = 0;

            foreach (var child in _children)
            {
                if (child.Name == name) ++childrenOfName;
            }

            return childrenOfName;
        }

        // Used in solution to Exercise 3
        public double GetAverageAgeOf(string name)
        {

            double sumOfAge = 0.0;
            double countOfAge = GetNChildrenOfName(name);

            if (countOfAge == 0) throw new ArgumentOutOfRangeException();

            foreach (var child in _children)
            {
                if (child.Name == name) sumOfAge += child.Age;
            }

            return sumOfAge/countOfAge;
        }

        // Used in solution to Exercise 4
        public int GetNChildrenOfAge(int age)
        {
            int childrenOfAge = 0;

            foreach (var child in _children)
            {
                if (child.Age == age) ++childrenOfAge;
            }

            return childrenOfAge;
        }

        // Used in solution to Exercise 5
        public int GetNChildrenOfNames(List<string> names)
        {
            int totalChildrenOfNames = 0;
            foreach (var name in names)
            {
                totalChildrenOfNames += GetNChildrenOfName(name);
            }

            return totalChildrenOfNames;
        }

        // Used in solution to Exercise 6: 
        // The total list of unique names (from this method) "minus" the list of unique boys' names = list of unique girls' names.
        public List<string> GetUniqueNames()
        {
            // Generate list of names
            List<string> names = new List<string>();

            // Run through all childrens' names
            foreach (var child in _children)
            {
                // If name is not in the list, add it to the list (ensures names are unique)
                if(!names.Contains(child.Name))
                    names.Add(child.Name);
            }

            // List ofunique  names is now complete - return it
            return names;
        }



        // Used in solution to Exercise 7
        public bool IsMostBoys(List<string> boysNames)
        {
            if (GetNChildrenOfNames(boysNames) > GetNChildren() / 2) return true;
            else return false;
        }


        // Used in solution to Exercise 8
        public string GetMostPopularNameOf(List<string> names)
        {
            string mostPopularName = "N/A";
            int mostPopularCount = 0;

            foreach (var name in names)
            {
                var count = GetNChildrenOfName(name);
                if (count> mostPopularCount)
                {
                    mostPopularCount = count;
                    mostPopularName = name;
                }
            }
            return mostPopularName;
        }


    }
}
