﻿using System;
using System.Collections.Generic;
using System.Linq;
using Children;

namespace ChildrenMain
{
    class Program
    {
        private static string SOFIE = "Sofie";
        private static string OSCAR = "Oscar";
        private static string[] BOYS_NAMES = new[]
        {
            "Noah", "Victor", "Oliver", "Oscar", "William", "Lucas", "Carl", "Malthe", "Emil", "Alfred",
            "Frederik", "Valdemar", "Magnus", "Elias", "Christian", "Alexander", "August", "Anton", "Villads", "Aksel",
            "Nohr", "Johan", "Liam", "Sebastian", "Mikkel"
        };
        

        static void Main(string[] args)
        {
            var childrenLines = System.IO.File.ReadAllLines(@"childnames.txt");
            var children = childrenLines.Select(child => Child.Create(child)).ToList();
            var childCalculator = new ChildCalculator();
            // var childCalculator = new ChildCalculatorLinq();

            // Exercise 1
            Console.WriteLine("Number of children: {0}", children.Count());

            // Exercise 2
            ChildrenNamedSofie(childCalculator, children);
            
            // Exercise 3
            AverageAgeOfOscars(childCalculator, children);
            
            // Exercise 4
            NumberOfSixYearOldChildren(childCalculator, children);
            
            // Exercise 5
            NumberOfBoys(childCalculator, children);
            
            // Exercise 6
            PrintGirlsName(childCalculator, children);
            
            // Exercise 7
            WhichGenderHasMostChildren(childCalculator, children);
            
            // Exercise 8
            MostPopularNames(childCalculator, children);
        }

        private static void MostPopularNames(IChildCalculator childCalculator, List<Child> children)
        {
            var mostPopularBoyName = childCalculator.MostPopularName(children, BOYS_NAMES.ToList());
            var girlsNames = childCalculator.FindNamesNotInList(children, BOYS_NAMES.ToList());
            var mostPopularGirlName = childCalculator.MostPopularName(children, girlsNames);

            Console.WriteLine("Most popular name among the boys are: {0}", mostPopularBoyName);
            Console.WriteLine("Most popular name among the Girls are: {0}", mostPopularGirlName);
        }

        private static void WhichGenderHasMostChildren(IChildCalculator childCalculator, List<Child> children)
        {
            var boys = childCalculator.FindChildrenWithNames(children, BOYS_NAMES.ToList()).Count();
            var girlsNames = childCalculator.FindNamesNotInList(children, BOYS_NAMES.ToList());
            var girls = childCalculator.FindChildrenWithNames(children, girlsNames).Count();

            Console.WriteLine("There are more {0}", (boys > girls ? "boys" : "girls"));
        }

        private static void PrintGirlsName(IChildCalculator childCalculator, List<Child> children)
        {
            var girlNames = childCalculator.FindNamesNotInList(children, BOYS_NAMES.ToList());

            string girlNamesString = string.Join(", ", girlNames);
            Console.WriteLine("Girls names are: {0}", girlNamesString);
        }

        private static void NumberOfBoys(IChildCalculator childCalculator, List<Child> children)
        {
            var boysCount = childCalculator.CountChildrenInList(children, BOYS_NAMES.ToList());
            Console.WriteLine("Number of boys: {0}", boysCount);
        }

        private static void NumberOfSixYearOldChildren(IChildCalculator childCalculator, List<Child> children)
        {
            int sixYearCounter = childCalculator.NumberOfChildrenAged(children, 6);
            Console.WriteLine("Number of 6 year old children: {0}", sixYearCounter);
        }

        private static void AverageAgeOfOscars(IChildCalculator childCalculator, List<Child> children)
        {
            double averageAgeOfOscar = childCalculator.AverageAgeOfChild(children, OSCAR);
            Console.WriteLine("Average age of {0}'s: {1}", OSCAR, averageAgeOfOscar);
        }

        private static void ChildrenNamedSofie(IChildCalculator childCalculator, List<Child> children)
        {
            int sofieCounter = childCalculator.ChildrenNamed(children, SOFIE);
            Console.WriteLine("Number of children named {0}: {1}", SOFIE, sofieCounter);
        }
    }
}