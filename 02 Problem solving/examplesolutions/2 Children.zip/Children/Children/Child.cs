﻿using System;

namespace Children
{
    public class Child
    {
        public readonly string name;
        public readonly int age;

        public Child(string name, int age)
        {
            this.name = name;
            this.age = age;
        }

        public static Child Create(string line)
        {
            var strings = line.Split(",");
            return new Child(strings[0].Trim(), int.Parse(strings[1].Trim()));
        }
    }
}