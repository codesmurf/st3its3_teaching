using System.Collections.Generic;

namespace Children
{
    public interface IChildCalculator
    {
        int ChildrenNamed(List<Child> children, string name);
        double AverageAgeOfChild(List<Child> children, string name);
        int NumberOfChildrenAged(List<Child> children, int age);
        int CountChildrenInList(List<Child> children, List<string> names);
        List<string> FindNamesNotInList(List<Child> children, List<string> names);
        List<Child> FindChildrenWithNames(List<Child> children, List<string> names);
        string MostPopularName(List<Child> children, List<string> names);
    }
}