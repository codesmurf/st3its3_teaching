using System.Collections.Generic;
using System.Linq;

namespace Children
{
    public class ChildCalculatorLinq : IChildCalculator
    {
        public int ChildrenNamed(List<Child> children, string name)
        {
            return children.Count(child => name.Equals(child.name));
        }

        public double AverageAgeOfChild(List<Child> children, string name)
        {
            return children
                .Where(child => name.Equals(child.name))
                .Select(child => child.age)
                .Average();
        }

        public int NumberOfChildrenAged(List<Child> children, int age)
        {
            return children.Count(child => child.age == age);
        }

        public int CountChildrenInList(List<Child> children, List<string> names)
        {
            return children.Count(child => names.Contains(child.name));
        }

        public List<string> FindNamesNotInList(List<Child> children, List<string> names)
        {
            return children.Where(child => !names.Contains(child.name))
                .Select(child => child.name)
                .Distinct()
                .ToList();
        }

        public List<Child> FindChildrenWithNames(List<Child> children, List<string> names)
        {
            return children.Where(child => names.Contains(child.name)).ToList();
        }

        public string MostPopularName(List<Child> children, List<string> names)
        {
            return children
                .Where(child => names.Contains(child.name))
                .GroupBy(child => child.name)
                .OrderByDescending(group => @group.Count())
                .First().Key;
            /*
             * Not forced to do this via the interface where you first need to find the girl names
            var mostPopularGirlName2 = children
                 .Where(child => !BOYS_NAMES.Contains(child.name))
                 .GroupBy(child => child.name)
                 .OrderByDescending(group => @group.Count())
                 .First().Key;

             */
        }
    }
}