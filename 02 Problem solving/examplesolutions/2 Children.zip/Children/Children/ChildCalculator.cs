using System;
using System.Collections.Generic;
using System.Linq;

namespace Children
{
    public class ChildCalculator : IChildCalculator
    {
        public int ChildrenNamed(List<Child> children, string name)
        {
            int counter = 0;
            foreach (var child in children)
            {
                if (name.Equals(child.name))
                {
                    counter++;
                }
            }

            return counter;
        }

        public double AverageAgeOfChild(List<Child> children, string name)
        {
            int counter = 0;
            float ageSum = 0;
            foreach (var child in children)
            {
                if (name.Equals(child.name))
                {
                    counter++;
                    ageSum += child.age;
                }
            }

            return (ageSum / counter);
        }

        public int NumberOfChildrenAged(List<Child> children, int age)
        {
            int counter = 0;
            foreach (var child in children)
            {
                if (child.age == age)
                {
                    counter++;
                }
            }

            return counter;
        }

        public int CountChildrenInList(List<Child> children, List<string> names)
        {
            return FindChildrenWithNames(children, names.ToList()).Count();
        }
        
        public List<string> FindNamesNotInList(List<Child> children, List<string> names)
        {
            var newNames = new HashSet<string>();
            foreach (var child in children)
            {
                if (!names.Contains(child.name))
                {
                    newNames.Add(child.name);
                }
            }

            return newNames.ToList();
        }

        public List<Child> FindChildrenWithNames(List<Child> children, List<string> names)
        {
            var filteredChildren = new List<Child>();
            foreach (var child in children)
            {
                if (names.Contains(child.name))
                {
                    filteredChildren.Add(child);
                }
            }

            return filteredChildren;
        }
        
        public string MostPopularName(List<Child> children, List<string> names)
        {
            var childrenWithNames = FindChildrenWithNames(children, names);
            var namesNumber = new Dictionary<string, int>();
            foreach (var child in childrenWithNames)
            {
                if (namesNumber.ContainsKey(child.name))
                {
                    namesNumber[child.name] = namesNumber[child.name]+1;
                }
                else
                {
                    namesNumber.Add(child.name, 0);
                }
            }

            return namesNumber.OrderByDescending(pair => pair.Value).First().Key;
        }
    }
}