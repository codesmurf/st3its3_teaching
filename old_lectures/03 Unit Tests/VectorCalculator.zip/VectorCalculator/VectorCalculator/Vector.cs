﻿
namespace VectorCalculator
{
    public class Vector
    {
        public double X { get; set; }
        public double Y { get; set; }
    }


    public class PolarVector
    {
        public double R { get; set; }
        public double Theta { get; set; }
    }
}
