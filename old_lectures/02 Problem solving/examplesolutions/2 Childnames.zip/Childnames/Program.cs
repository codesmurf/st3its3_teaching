﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Childnames
{
    class Program
    {
        static void Main(string[] args)
        {
            Kindergarten kindergarten = new Kindergarten();
            kindergarten.ReadPersons();

            kindergarten.CountNumberOfPersons();

            kindergarten.CountNumberOf("Sofie");

            kindergarten.FindAverageAgeOf("Oscar");

            kindergarten.FindNumberOfPersonsOfAge(6);
            kindergarten.CountAllBoys();

            kindergarten.FindGirlsNames();

            kindergarten.AreThereMostBoysOrGirls();

            Console.WriteLine("press key");
            Console.ReadKey();
        }
    }
}
