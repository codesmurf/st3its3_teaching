﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Childnames
{
    class Kindergarten
    {
        // create local list of persons
        List<Person> personList = new List<Person>();

        private List<string> boysNames = new List<string> {"Noah", "Victor", "Oliver", "Oscar", "William", "Lucas",
            "Carl", "Malthe", "Emil", "Alfred","Frederik", "Valdemar", "Magnus", "Elias", "Christian", "Alexander", "August", "Anton", "Villads", "Aksel",
            "Nohr","Johan", "Liam", "Sebastian","Mikkel"};

        public void ReadPersons()
        {

            // read file
            string[] lines = System.IO.File.ReadAllLines(@"..\..\..\childnames.txt");

            foreach (string line in lines)
            {
                // split in name and age
                string[] splitLine = line.Split(',');
                string name = splitLine[0];
                string age = splitLine[1];

                int ageAsInt = Convert.ToInt32(age);

                // create person objects
                Person p = new Person(name, ageAsInt);
                personList.Add(p);

                //System.Console.WriteLine(line);
            }


        }

        public void CountNumberOfPersons()
        {
            int numberOfPersons = personList.Count;
            Console.WriteLine("Number of persons: " + numberOfPersons);
        }

        public void CountNumberOf(string name)
        {
            int count = 0;
            // go through list
            foreach (Person person in personList)
            {
                if (person.Name == name)
                {
                    count++;
                }
            }
            Console.WriteLine("There are {0} persons named {1}", count, name);
        }

        public void FindAverageAgeOf(string name)
        {
            int count = 0;
            double totalSum = 0;

            // go through list
            foreach (Person person in personList)
            {
                if (person.Name == name)
                {
                    count++;
                    totalSum = totalSum + person.Age;
                }
            }

            double averageAge = totalSum / count;

            Console.WriteLine("Average age of {0} is {1:F1}", name, averageAge);
        }

        public void FindNumberOfPersonsOfAge(int age)
        {
            int count = 0;

            // go through list
            foreach (Person person in personList)
            {
                if (person.Age == age)
                {
                    count++;
                }
            }

            Console.WriteLine("The are {0} of age {1}", count, age);
        }

        public int CountAllBoys()
        {
            int numberOfBoys = 0;
           // go through list of boys
            foreach (Person person in personList)
            {
                if (boysNames.Contains(person.Name))
                {
                    numberOfBoys++;
                }
            }
            Console.WriteLine("Number of boys: " + numberOfBoys);
            return numberOfBoys;
        }

        public void FindGirlsNames()
        {
            // A Set can only contain the same value once
            HashSet<string> girlsNames = new HashSet<string>();
            foreach (Person p in personList)
            {
                if (!boysNames.Contains(p.Name))
                {
                    // it must be a girl
                    girlsNames.Add(p.Name);
                }
            }

            foreach (string girlsName in girlsNames)
            {
                Console.WriteLine(girlsName);
            }
        }

        public void AreThereMostBoysOrGirls()
        {
            int numberOfChildren = personList.Count;
            int numberOfBoys = CountAllBoys();
            int numberOfGirls = numberOfChildren - numberOfBoys;

            if (numberOfBoys > numberOfGirls)
            {
                Console.WriteLine("There are more boys than girls");
            }
            else if (numberOfGirls > numberOfBoys)
            {
                Console.WriteLine("There are more girls than boys");
            } else
            {
                Console.WriteLine("The are the same number of boys and girls");
            }
        }
    }
}
