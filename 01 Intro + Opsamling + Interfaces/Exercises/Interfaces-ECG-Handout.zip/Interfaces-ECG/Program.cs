﻿using System;

namespace Interfaces_ECG
{
    class Program
    {
        static void Main(string[] args)
        {
            ECGContainer container = new ECGContainer();

            for (int i = 0; i < 100; i++) // Add samples
            {
                container.AddSample(i % 8);   // Add values in the range [0..7]
            }
            container.ProcessSamples();

            // Wait for keypress before exiting (otherwise the program exits a debug session)
            Console.WriteLine("Press a key to exit.");
            Console.ReadKey();
        }
    }
}
