﻿using System;
using System.Collections.Generic;

namespace Interfaces_ECG
{
    public class Processing
    {
        public void Process(List<int> samples)
        {
            foreach (var sample in samples)
            {
                Console.WriteLine("Sample: {0}", sample);
            }
        }
    }
}
