﻿using System;
using System.Collections.Generic;

namespace Interfaces_ECG
{
    class BPMProcessing : IProcessing
    {
        private const int Threshold = 21;

        public void Process(List<int> samples)
        {
            // To count the heartbeat, we shall count the number of times
            // the sample values goes from below 21 to 21 or above.
            // The sampling rate is 1000Hz, which means 1000 samples pr. second.
            // So we will have 60000 samples in the timeframe of 1 minute,
            //                120000 samples in the timeframe of 2 minutes,
            //                180000 samples in the timeframe of 3 minutes
            //                etc...
            // So if we have e.g. 180000 samples, we have to divide the
            // counted number of heartbeats with (180000/60000) to get the BPM.
            double divisor = Convert.ToDouble(samples.Count) / 60000;

            int transitionCount = 0;
            int previousSample = samples[0];
            for (int i = 1; i < samples.Count; i++)
            {
                int currentSample = samples[i];
                if (previousSample < Threshold
                    && currentSample >= Threshold)
                {
                    transitionCount++;
                }
                previousSample = currentSample;
            }

            double transitions = transitionCount; // Convert int to double, so precision is not lost in the division below.
                                                  // I could also have used Convert.ToDouble() like I did with the divisor.

            double beatsPerMinute = transitions / divisor;
            Console.WriteLine("BPM: {0}", beatsPerMinute);

        }
    }
}
