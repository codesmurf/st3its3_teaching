﻿using System;

namespace Interfaces_ECG
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Select processing method:");
            Console.WriteLine("1: Print all sample values");
            Console.WriteLine("2: Print max and min sample values");
            Console.WriteLine("3: Print BPM");

            ECGContainer container = null;
            bool methodNotSelected = true;
            do
            {
                var consoleKeyInfo = Console.ReadKey(true);
                if (consoleKeyInfo.KeyChar == '1')
                {
                    container = new ECGContainer(new Processing());
                    methodNotSelected = false;
                }
                else if (consoleKeyInfo.KeyChar == '2')
                {
                    container = new ECGContainer(new ExtremesProcessing());
                    methodNotSelected = false;
                }
                else if (consoleKeyInfo.KeyChar == '3')
                {
                    container = new ECGContainer(new BPMProcessing());
                    methodNotSelected = false;
                }

            } while (methodNotSelected);


            // Generate 60000 ((50 + 50) * 10 * 60) samples
            // with 60 transitions from below 20 to above 20.
            // This should give a BPM of 60.
            for (int j = 0; j < 60; j++)
            {
                for (int i = 0; i < 50; i++)
                {
                    for (int g = 0; g < 10; g++)
                    {
                        container.AddSample(i);
                    }
                }
                for (int i = 50; i > 0; i--)
                {
                    for (int g = 0; g < 10; g++)
                    {
                        container.AddSample(i);
                    }
                }
            }

            container.ProcessSamples();

            // Wait for keypress before exiting (otherwise the program exits a debug session)
            Console.WriteLine("Press a key to exit.");
            Console.ReadKey();
        }
    }
}
