﻿using System;
using System.Collections.Generic;

namespace Interfaces_ECG
{
    class ExtremesProcessing : IProcessing
    {
        public void Process(List<int> samples)
        {
            // make sure there is at least 1 sample, before trying to use the
            // first sample in the code below.
            if (samples.Count == 0)
            {
                return;
            }

            // initialize with sane values
            int maxSample = samples[0];
            int minSample = samples[0];

            foreach (var sample in samples)
            {
                if (maxSample < sample)
                {
                    maxSample = sample;
                }
                if (minSample > sample)
                {
                    minSample = sample;
                }
            }

            Console.WriteLine("Max: {0}, Min: {1}", maxSample, minSample);
        }
    }
}
