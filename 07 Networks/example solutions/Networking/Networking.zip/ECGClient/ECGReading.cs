﻿namespace ECGClient;

internal class ECGReading
{
    public int Reading { get; set; }
}