﻿namespace ECGServer;

internal class ECGReading
{
    public int Reading { get; set; }
}