﻿namespace ECGClient;

internal interface IECGSensor
{
    public int GenerateSample();
}